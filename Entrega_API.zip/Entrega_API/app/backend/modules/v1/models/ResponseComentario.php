<?php

namespace app\modules\v1\models;

class ResponseComentario
{
    public $success;
    public $mensagem;
    public $comentario;
}