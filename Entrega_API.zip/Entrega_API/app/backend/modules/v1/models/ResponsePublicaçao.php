<?php

namespace app\modules\v1\models;

class ResponsePublicaçao
{
    public $success;
    public $mensagem;
    public $publicacao;
}