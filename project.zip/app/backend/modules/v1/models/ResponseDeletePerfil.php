<?php

namespace app\modules\v1\models;

class ResponseDeletePerfil
{
    public $success;
}