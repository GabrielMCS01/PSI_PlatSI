<?php

namespace app\modules\v1\models;

class ResponseUpdatePerfil
{
    public $success;
}