<?php

namespace app\modules\v1\models;

class ResponsePerfil
{
    public $primeiro_nome;
    public $ultimo_nome;
    public $data_nascimento;
}