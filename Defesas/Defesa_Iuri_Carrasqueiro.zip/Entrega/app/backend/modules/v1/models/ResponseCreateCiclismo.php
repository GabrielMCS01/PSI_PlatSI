<?php

namespace app\modules\v1\models;

class ResponseCreateCiclismo
{
    public $success;
}