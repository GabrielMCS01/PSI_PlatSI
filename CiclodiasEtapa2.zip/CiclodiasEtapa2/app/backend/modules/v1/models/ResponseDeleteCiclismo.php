<?php

namespace app\modules\v1\models;

class ResponseDeleteCiclismo
{
    public $success;
}