<?php

namespace app\modules\v1\models;

class ResponseRegisto
{
    public $success;
}