<?php

namespace app\modules\v1\models;

class ResponseSync
{
    public $ids = array();
}