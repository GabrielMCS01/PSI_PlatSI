<?php

namespace app\modules\v1\models;

class ResponsePerfil
{
    public $success;
    public $mensagem;
    public $primeiro_nome;
    public $ultimo_nome;
    public $data_nascimento;
}