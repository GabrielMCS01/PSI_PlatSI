<?php

namespace app\modules\v1\models;

class ResponseLogin
{
    public $success;
    public $token;
    public $id;
    public $primeiro_nome;
    public $ultimo_nome;
    public $mensagem;

}