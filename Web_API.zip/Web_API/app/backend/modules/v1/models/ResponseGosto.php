<?php

namespace app\modules\v1\models;

class ResponseGosto
{
    public $success;
    public $mensagem;
    public $gosto;
}