<?php

namespace app\modules\v1\models;

class ResponseCiclismo
{
    public $success;
    public $mensagem;
    public $ciclismo;
}