CREATE DATABASE `projectdb`;

USE projectdb;