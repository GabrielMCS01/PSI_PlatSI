CREATE DATABASE `projectdb_test`;

USE projectdb_test;